# Deep Learning Toolkit v1.0.0
This toolkit provides Neural Network.

  
  
  
  
## Required packages
* tensorflow
* keras
* numpy
* matplotlib

## Contents
* DNN(Deep Neural Network) : DNN() in DNN.py

